import React, { useState, useEffect } from "react";
import axios from "axios";
import Country from "./country";
import Category from "./Category";

let Header = () => {
  const [header, setHeader] = useState();

  const getAPIData = async () => {
    try {
      const { data } = await axios.get(
        "https://newsapi.org/v2/everything?q=tesla&from=2021-07-03&sortBy=publishedAt&apiKey=262ca29f445840a596e6301fc64290dd"
      );
      
      setHeader(data.articles);
    } catch {}
  };
  useEffect(() => { 
    
  getAPIData();
  }, []);
  
  return (
    <>
    <div id="container">
        <nav className="navbar navbar-expand-lg navbar-light bg-light position-sticky">
            <div className="container-fluid">
                <a className="navbar-brand" href="#">Coradius.in</a>
                <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span className="navbar-toggler-icon"></span>
                </button>
            </div>
        </nav>
        <div className="container">
            <div className="row">
                <div className="col-md-12 mt-5">
                    <Country/>
                </div>
                <div className="col-md-12 mt-2">
                    <Category/>
                </div>
            </div>
        </div>
        <h1 className="text-center mt-5 mb-5">NEWS API</h1>
        
            {header && header.map((item, idx) => <div key= {idx}>
                <div className="container p-5" style={{background:"lightgray"}}>
                    <div className="shadow p-3 m-1">
                        <ul style={{listStyle:'none'}}>
                            <b>Title :</b><li>{item.title}</li>
                            <br />
                            <b>Author</b><li>{item.author}</li>
                            <b>Description</b><li>{item.description}</li>
                            <img src={item.urlToImage} alt="image" width="50%"/><br/>
                            <span className="text-muted">Published At</span ><li>{item.publishedAt}</li>
                        </ul>
                    </div>
                </div>
        </div>)}
    </div>  
    </>
  );
};
export default Header;
