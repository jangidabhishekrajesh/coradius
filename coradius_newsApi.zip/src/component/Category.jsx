import React, { useState, useEffect } from "react";
import axios from "axios";

let Category = () => {
  const [category, setCategory] = useState();

  const getAPIData = async (category) => {
    try {
      debugger;
      const { data } = await axios.get(
        `https://newsapi.org/v2/top-headlines?category=${category}&apiKey=262ca29f445840a596e6301fc64290dd`
      );
      setCategory(data.articles);
    } catch {}
  };

  useEffect(() => {
    getAPIData();
  }, []);

  return (
    <>
      <div id="container">
          <div className="col-md-3">
            <input
              type="text"
              className="form-control"
              placeholder="Search by Category"
              onChange={(event) => getAPIData(event.target.value)}
            />
          </div>
        <div className="container">
          <div className="col-md-12">
            {category &&
              category.map((item, idx) => (
                <div key={idx}>
                  <div className="p-5" style={{ background: "lightgray" }}>
                    <div className="shadow p-3 m-1">
                      <ul style={{ listStyle: "none" }}>
                        <b>Title :</b>
                        <li>{item.title}</li>
                        <br />
                        <b>Author</b>
                        <li>{item.author}</li>
                        <b>Description</b>
                        <li>{item.description}</li>
                        <img src={item.urlToImage} alt="image" width="50%" />
                        <br />
                        <span className="text-muted">Published At</span>
                        <li>{item.publishedAt}</li>
                      </ul>
                    </div>
                  </div>
                </div>
              ))}
          </div>
        </div>
      </div>
    </>
  );
};

export default Category;
